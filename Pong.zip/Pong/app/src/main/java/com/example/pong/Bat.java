package com.example.pong;

public class Bat {
}
